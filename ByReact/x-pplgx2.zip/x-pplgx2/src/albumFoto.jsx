import React from "react";
import TypeIt from "typeit-react";
import Swal from "sweetalert2";
import Header from "./HEADER";
import { Link } from "react-router-dom";
import Tailwind from "tailwindcss"
function pernapasan(params) {
    return(
        
        <div>
            <style>

    .caveat-
        font-family: "Caveat", cursive;
        font-optical-sizing: auto;
        font-weight: 400;
        font-style: normal;
            </style>
            <Header />
            <h1 className="flex justify-center mb-20 mt-10 text-3xl font-bold text-bold">INI ADALAH ALBUM KAMI SELAMA BERSEKOLAH</h1>
            <div className="flex justify-center items-center min-h-screen bg-gray-100">
  
  <div className="bg-gray-300 shadow-lg rounded-xl p-10 max-w-md w-full">
    <div className="text-center mb-4">
      <p className="text-xs">ありがとう</p>
      <p className="text-sm font-medium">FOTO PERTAMA</p>
      <p className="text-2xl font-bold">AGUSTUSAN 2024</p>
    </div>

    <div className="space-y-4">
      <ul className="flex justify-between text-sm font-semibold">
        <li>WILDAN</li>
        <li>SAKHA</li>
        <li>GALANG</li>
        <li>FAHRI</li>
      </ul>

      <ul className="flex justify-between text-sm font-semibold">
        <li>ARBI</li>
        <li>SADEWA</li>
        <li>JEVON</li>
        <li>RAFAEL</li>
        <li>KEYSA</li>
      </ul>

      <img
        src="17agustusan.jpg"
        alt="Foto Agustusan"
        className="rounded-lg w-full object-cover"
      />
    </div>
  </div>
</div>
<style>
@import url('https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap');
</style>
</div>

    )
}

export default pernapasan